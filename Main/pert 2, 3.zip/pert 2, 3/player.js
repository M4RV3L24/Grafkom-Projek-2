import * as THREE from 'three';

export class Player {
    constructor(camera, controller, scene, speed){
        this.camera = camera;
        this.controller = controller;
        this.scene = scene;
        this.speed = speed;

        this.camera.setup(new THREE.Vector3(0,0,0));

        this.mesh = new THREE.Mesh(
            new THREE.BoxGeometry(1,1,1),
            new THREE.MeshPhongMaterial({color: 0xFF1111})
        );
        this.mesh.castShadow = true;
        this.mesh.receiveShadow = true;
        this.scene.add(this.mesh);
    }

    update(dt){
        var direction = new THREE.Vector3(0,0,0);
        if(this.controller.keys['forward']){
            direction.x = 1;
        };
        if(this.controller.keys['backward']){
            direction.x = -1;
        };
        if(this.controller.keys['left']){
          ;  direction.z = -1;
        }
        if(this.controller.keys['right']){
           ; direction.z = 1;
        }
        
        this.mesh.position.add(direction.multiplyScalar(dt*this.speed));
        this.camera.setup(this.mesh.position);
    }


}

export class PlayerController {
    constructor() {
        this.keys = {
            "forward": false,
            "backward": false,
            "left": false,
            "right": false
        };
        this.mousePos = new THREE.Vector2();
        this.mouseDown = false;
        this.deltaMousePos = new THREE.Vector2();
        document.addEventListener("keydown", (e) => this.onKeyDown(e), false );
        document.addEventListener("keyup", (e) => this.onKeyUp(e), false);
        document.addEventListener("mousemove", (e) => this.onMouseMove(e), false);
        document.addEventListener("mouseup", (e) => this.onMouseUp(e), false);
        document.addEventListener("mousedown", (e) => this.onMouseDown(e), false);
        
    }

    onMouseDown(e) {
        this.mouseDown = true;
    }
    onMouseMove(e) {
        var currentMousePos = new THREE.Vector2 (
            (e.clientX/ window.innerWidth) * 2 - 1,
            -(e.clientY/ window.innerHeight) * 2 +1
        );
        this.deltaMousePos.addVectors(currentMousePos, this.mousePos.multiplyScalar(-1));
        this.mousePos.copy(currentMousePos);
        console.log(this.deltaMousePos);

    }
    onMouseUp(e) {
        this.mouseDown = false;
    }

    onKeyDown (e) {
        console.log(e.key);
        switch(e.keyCode) {
            case 87: //w
                this.keys.forward = true;
                break;
            case 83: //s
                this.keys.backward = true;
                break;
            case 65: //a
                this.keys.left = true;
                break;
            case 68: //d
                this.keys.right = true;
                break;
        }
    }

    onKeyUp (e) {
        console.log(e.key);
        switch(e.keyCode) {
            case 87: //w
                this.keys.forward = false;
                break;
            case 83: //s
                this.keys.backward = false;
                break;
            case 65: //a
                this.keys.left = false;
                break;
            case 68: //d
                this.keys.right = false;
                break;
        }
    }
    
}

export class ThirdPersonCamera {
    constructor(camera, positionOffset, targetOffset) {
        this.camera = camera;
        this.positionOffset = positionOffset;
        this.targetOffset = targetOffset;
    }

    setup(target){
        var temp = new THREE.Vector3(0,0,0);
        temp.addVectors(target, this.positionOffset);
        this.camera.position.copy(temp);
        temp = new THREE.Vector3(0,0,0);
        temp.addVectors(target, this.targetOffset);
        this.camera.lookAt(temp);
    }
}